import { useState } from "react";
import styles from "./Projects.module.scss";
import type { Project } from "../data/projects";
import { projects as baseProjects } from "../data/projects";
import ProjectDetail from "../components/ProjectDetail";
import ProjectCard from "../components/ProjectCard";
import "../components/CrtButton.scss";

export default function Projects() {
  const [selected, setSelected] = useState<Project | null>(null);

  const projects = baseProjects.map((p) => ({
    ...p,
    tech: (p.tech ?? ["React", "Node.js", "MongoDB"]).filter(Boolean),
    features: (p.features ?? []).filter(
      (f) => typeof f === "string" && f.trim() !== ""
    ),
  }));

  // 👇 SEMPRE abre o detalhe
  function handleMore(p: Project) {
    setSelected(p);
  }

  return (
    <section id="projetos" className={`section ${styles.projects}`}>
      <div className="container">
        <h2
          className="matrix-text"
          style={{ marginBottom: 24, fontSize: "clamp(32px,4.5vw,48px)" }}
        >
          {"> PROJETOS"}
        </h2>

        <ul className={styles.grid} aria-label="Lista de projetos">
          {projects.map((p, i) => (
            <ProjectCard
              key={i}
              project={p}
              onMore={handleMore} // 👈 passa o handler correto
              onFallback={() => setSelected(p)} // (opcional) mantém fallback
            />
          ))}
        </ul>
      </div>

      {selected && (
        <ProjectDetail project={selected} onBack={() => setSelected(null)} />
      )}
    </section>
  );
}
