import { useEffect, useMemo, useState } from "react";
import s from "./Sobre.module.scss";

/** Hook typewriter com reduced-motion e guardas */
function useTypewriter(
  words: string[],
  opts?: {
    typeSpeed?: number;
    deleteSpeed?: number;
    holdTime?: number;
    loop?: boolean;
    reducedMotion?: boolean;
  }
) {
  const {
    typeSpeed = 80,
    deleteSpeed = 40,
    holdTime = 1200,
    loop = true,
    reducedMotion = false,
  } = opts || {};

  const safeWords = words?.length ? words : [""];
  const [wordIndex, setWordIndex] = useState(0);
  const [text, setText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (reducedMotion) {
      setText(safeWords[Math.min(wordIndex, safeWords.length - 1)] ?? "");
      return;
    }

    let timeoutId: ReturnType<typeof setTimeout> | null = null;

    const current = safeWords[wordIndex] ?? "";
    const isDoneTyping = text === current;
    const isDoneDeleting = text === "";

    if (!isDeleting) {
      timeoutId = setTimeout(
        () => {
          if (!isDoneTyping) {
            setText(current.slice(0, text.length + 1));
          } else {
            setIsDeleting(true);
          }
        },
        isDoneTyping ? holdTime : typeSpeed
      );
    } else {
      timeoutId = setTimeout(() => {
        if (!isDoneDeleting) {
          setText(current.slice(0, text.length - 1));
        } else {
          const nextIndex = (wordIndex + 1) % safeWords.length;
          if (!loop && nextIndex === 0) {
            setIsDeleting(false);
            setText(safeWords[safeWords.length - 1] ?? "");
            return;
          }
          setIsDeleting(false);
          setWordIndex(nextIndex);
        }
      }, deleteSpeed);
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [
    text,
    isDeleting,
    wordIndex,
    safeWords,
    typeSpeed,
    deleteSpeed,
    holdTime,
    loop,
    reducedMotion,
  ]);

  return { text };
}

const WORDS = [
  "Full-Stack Developer",
  "Front-End Developer",
  "Back-End Developer",
];

export default function Sobre() {
  const [prefersReduced, setPrefersReduced] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!mq) return;
    const apply = () => setPrefersReduced(mq.matches);
    apply();
    mq.addEventListener?.("change", apply);
    return () => mq.removeEventListener?.("change", apply);
  }, []);

  const words = useMemo(() => WORDS, []);
  const { text } = useTypewriter(words, {
    typeSpeed: 70,
    deleteSpeed: 40,
    holdTime: 1000,
    loop: true,
    reducedMotion: prefersReduced,
  });

  return (
    <section id="sobre" className={`section ${s.sobre}`}>
      <div className={s.text}>
        <h1 className={`${s.name} matrix-text`}>
          <span>Gustavo</span>
          <span>Fernandez</span>
        </h1>

        <h2 className={s.role}>
          <span
            className={s.type}
            role="status"
            aria-live="polite"
            aria-atomic="true"
          >
            {text}
            <span className={s.caret} aria-hidden="true" />
          </span>
        </h2>

        <p className={s.summary}>
          Olá! Eu sou um estudante da UNIFAL, atualmente no oitavo período.
          Desenvolvedor JR que adora resolver problemas e desafios. Tenho
          experiências práticas recentes com Node.js, React, JavaScript e banco
          de dados.
        </p>
      </div>
    </section>
  );
}
