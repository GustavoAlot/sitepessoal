import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import styles from "./Resumo.module.scss";
import {
  SiJavascript,
  SiTypescript,
  SiPython,
  SiReact,
  SiNodedotjs,
  SiMysql,
  SiMongodb,
  SiFirebase,
  SiGit,
  SiC,
  SiCplusplus,
  SiTailwindcss,
} from "react-icons/si";

type Tech = { key: string; name: string; icon: ReactNode };

const TECHS: Tech[] = [
  { key: "js", name: "JavaScript", icon: <SiJavascript /> },
  { key: "ts", name: "TypeScript", icon: <SiTypescript /> },
  { key: "py", name: "Python", icon: <SiPython /> },
  { key: "react", name: "React", icon: <SiReact /> },
  { key: "node", name: "Node.js", icon: <SiNodedotjs /> },
  { key: "mysql", name: "MySQL", icon: <SiMysql /> },
  { key: "mongo", name: "MongoDB", icon: <SiMongodb /> },
  { key: "firebase", name: "Firebase", icon: <SiFirebase /> },
  { key: "git", name: "Git", icon: <SiGit /> },
  { key: "c", name: "C", icon: <SiC /> },
  { key: "cpp", name: "C++", icon: <SiCplusplus /> },
  { key: "tw", name: "Tailwind CSS", icon: <SiTailwindcss /> },
];

function shuffle<T>(arr: T[]) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function Resumo() {
  const rightRef = useRef<HTMLDivElement | null>(null);
  const leftRef = useRef<HTMLDivElement | null>(null);
  const [leftReady, setLeftReady] = useState(false);
  const [visibleMap, setVisibleMap] = useState<Record<string, number>>({});

  // delays aleatórios (60–700ms), estáveis por ciclo de vida
  const delays = useMemo(() => {
    const base = TECHS.map(
      (t) => [t.key, 60 + Math.round(Math.random() * 640)] as const
    );
    return new Map(shuffle(base));
  }, []);

  // direita: marca todos visíveis (com delays) quando entra no viewport do <main>
  useEffect(() => {
    const node = rightRef.current;
    const root = document.querySelector("main") || undefined;
    if (!node) return;

    const io = new IntersectionObserver(
      (entries, obs) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            const m: Record<string, number> = {};
            TECHS.forEach((t) => {
              m[t.key] = delays.get(t.key) ?? 0;
            });
            setVisibleMap(m);
            obs.unobserve(e.target); // one-shot
          }
        }
      },
      { root, threshold: 0.2, rootMargin: "0px 0px -10% 0px" }
    );

    io.observe(node);
    return () => io.disconnect();
  }, [delays]);

  // esquerda: ativa animação “empilhando”
  useEffect(() => {
    const node = leftRef.current;
    const root = document.querySelector("main") || undefined;
    if (!node) return;

    const io = new IntersectionObserver(
      (entries, obs) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setLeftReady(true);
            obs.unobserve(e.target);
          }
        }
      },
      { root, threshold: 0.2, rootMargin: "0px 0px -10% 0px" }
    );

    io.observe(node);
    return () => io.disconnect();
  }, []);

  return (
    <section id="resumo" className={`section ${styles.resumo}`}>
      <div className={styles.panel}>
        {/* Coluna esquerda */}
        <div
          ref={leftRef}
          className={`${styles.left} ${leftReady ? styles.stackReady : ""}`}
        >
          <div
            className={`${styles.block} ${styles.stackItem}`}
            style={{ ["--d" as any]: "280ms" }}
          >
            <h4 className={styles.role}>Formação</h4>
            <span className={styles.time}>
              Ciência da Computação (2021 — 2026)
            </span>
            <p className={styles.meta}>Universidade Federal de Alfenas</p>
          </div>

          <div
            className={`${styles.block} ${styles.stackItem}`}
            style={{ ["--d" as any]: "140ms" }}
          >
            <h4 className={styles.role}>Experiência</h4>
            <span className={styles.time}>
              Poligon Soluções (Abr 2025 — Presente)
            </span>
            <p className={styles.meta}>
              Estagiário de Desenvolvimento Front-end
            </p>
          </div>

          <div
            className={`${styles.block} ${styles.stackItem}`}
            style={{ ["--d" as any]: "210ms" }}
          >
            <h4 className={styles.role}>Experiência</h4>
            <span className={styles.time}>
              Factor3 Ventures (Set 2025 — Presente)
            </span>
            <p className={styles.meta}>Desenvolvedor Fullstack Jr</p>
          </div>

          <div
            className={`${styles.block} ${styles.stackItem}`}
            style={{ ["--d" as any]: "0ms" }}
          >
            <h4 className={styles.role}>Línguas</h4>
            <ul className={styles.langList}>
              <li>Português</li>
              <li>
                Inglês <span className={styles.langLevel}>(avançado)</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Coluna direita */}
        <div ref={rightRef} className={styles.right}>
          <ul className={styles.techGrid} aria-label="Tecnologias">
            {TECHS.map((t) => {
              const visible = t.key in visibleMap;
              const delay = visibleMap[t.key] ?? 0;
              return (
                <li
                  key={t.key}
                  className={`${styles.techItem} ${visible ? styles.show : ""}`}
                  style={{ transitionDelay: `${delay}ms` }}
                  title={t.name}
                  aria-label={t.name}
                  tabIndex={0}
                >
                  <div className={styles.icon} aria-hidden="true">
                    {t.icon}
                  </div>
                  <span className={styles.techName}>{t.name}</span>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </section>
  );
}
