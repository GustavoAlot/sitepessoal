import EmailSent from "../components/EmailSent";
import QuickLinks from "../components/QuickLinks";
import styles from "./Contact.module.scss";

export default function Contact() {
  return (
    <section id="contato" className={`section ${styles.contact}`}>
      <div className={styles.container}>
        <h2
          className="matrix-text"
          style={{ marginBottom: 16, fontSize: "clamp(32px,4.5vw,48px)" }}
        >
          {"> CONTATO"}
        </h2>

        <div className={styles.cols}>
          {/* Bloco esquerdo: seu form */}
          <div className={styles.col}>
            <EmailSent />
          </div>

          {/* Bloco direito: links rápidos */}
          <div className={styles.col}>
            <QuickLinks
              githubUrl="https://github.com/GustavoAlot"
              whatsappUrl="https://wa.me/+5567998158212"
              emailAddress="gusalot22@gmail.com"
              cvUrl="src/assets/GustavoFernandezPTBR.pdf"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
