import { useEffect, useMemo, useRef, useState } from "react";
import styles from "./NextSectionJump.module.scss";
import { CrtButton } from "../components/CrtButton";

type SectionId = "sobre" | "resumo" | "projetos" | "contato";

type Props = {
  ids?: SectionId[];
  active: SectionId;
  labelNext?: string;
  labelRestart?: string;
  onChange?: (id: SectionId) => void;
};

export default function NextSectionJump({
  ids = ["sobre", "resumo", "projetos", "contato"],
  active,
  labelNext,
  labelRestart,
  onChange,
}: Props) {
  const [reduced, setReduced] = useState(false);
  const navRef = useRef<HTMLElement | null>(null);

  // detecta nav (só para pegar altura)
  useEffect(() => {
    navRef.current = document.querySelector("nav");
  }, []);

  // prefers-reduced-motion
  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    if (!mq) return;
    const apply = () => setReduced(mq.matches);
    apply();
    mq.addEventListener?.("change", apply);
    return () => mq.removeEventListener?.("change", apply);
  }, []);

  const sections = useMemo(
    () =>
      ids
        .map((id) => document.getElementById(id))
        .filter((el): el is HTMLElement => !!el),
    [ids]
  );

  function getNavH(): number {
    const cssVar = parseFloat(
      getComputedStyle(document.documentElement).getPropertyValue(
        "--nav-height"
      )
    );
    return (
      navRef.current?.getBoundingClientRect().height ??
      (Number.isFinite(cssVar) ? cssVar : 0)
    );
  }

  function scrollToIndex(idx: number) {
    const target = sections[idx];
    if (!target) return;

    const navH = getNavH();
    const top = target.getBoundingClientRect().top + window.scrollY - navH;

    window.scrollTo({
      top,
      behavior: reduced ? "auto" : "smooth",
    });

    onChange?.(ids[idx]);
  }

  // 🔑 usa ACTIVE como base
  function handleNext() {
    const idx = ids.indexOf(active);
    const nextIdx = (idx + 1) % ids.length;
    scrollToIndex(nextIdx);
  }

  function handlePrev() {
    const idx = ids.indexOf(active);
    const prevIdx = (idx - 1 + ids.length) % ids.length;
    scrollToIndex(prevIdx);
  }

  // 🔑 label depende SOMENTE do estado real
  const isLast = active === ids[ids.length - 1];
  const btnLabel = isLast
    ? labelRestart ?? "Voltar ao topo"
    : labelNext ?? "Próxima seção";

  // atalhos de teclado
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (
        tag === "INPUT" ||
        tag === "TEXTAREA" ||
        (e.target as HTMLElement)?.isContentEditable
      )
        return;

      if (e.code === "Space" || e.key === "PageDown" || e.key === "ArrowDown") {
        e.preventDefault();
        handleNext();
      } else if (e.key === "PageUp" || e.key === "ArrowUp") {
        e.preventDefault();
        handlePrev();
      }
    };

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active, reduced]);

  return (
    <div className={`${styles.fab} ${reduced ? styles.noAnim : ""}`}>
      <CrtButton
        className="btn-crt--sm btn-crt--auto"
        onClick={handleNext}
        aria-label={btnLabel}
        title={btnLabel}
      >
        {btnLabel}
      </CrtButton>

      <button
        type="button"
        className={styles.nextBtn}
        onClick={handlePrev}
        aria-label="Seção anterior"
        title="Anterior (PgUp/↑)"
      >
        ◀
      </button>
    </div>
  );
}
