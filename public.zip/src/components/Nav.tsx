import { useEffect, useMemo, useRef } from "react";
import styles from "./Nav.module.scss";

export type SectionId = "sobre" | "resumo" | "projetos" | "contato";

type Props = {
  ids?: SectionId[];
  active: SectionId;
  onChange: (id: SectionId) => void;
};

export default function Nav({
  ids = ["sobre", "resumo", "projetos", "contato"],
  active,
  onChange,
}: Props) {
  const headerRef = useRef<HTMLElement | null>(null);

  // Mede a altura real da nav e injeta em --nav-height
  useEffect(() => {
    const el = headerRef.current;
    if (!el) return;

    const setVar = () => {
      const h = el.getBoundingClientRect().height;
      document.documentElement.style.setProperty("--nav-height", `${h}px`);
    };

    setVar();
    const ro = new ResizeObserver(setVar);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const items = useMemo(
    () => ids.map((id) => ({ id, label: `> ${id.toUpperCase()}` })),
    [ids]
  );

  return (
    <nav
      ref={headerRef}
      className={styles.nav}
      aria-label="Seções do portfólio"
    >
      <div className={styles.inner}>
        {items.map((it) => {
          const isActive = active === it.id;

          return (
            <a
              key={it.id}
              href={`#${it.id}`}
              className={`${styles.link} ${
                isActive ? `${styles.active} matrix-text` : ""
              }`}
              aria-current={isActive ? "page" : undefined}
              onClick={(e) => {
                e.preventDefault();

                // 1) atualiza o estado global
                onChange(it.id);

                // 2) faz o scroll respeitando a nav
                document.getElementById(it.id)?.scrollIntoView({
                  behavior: "smooth",
                  block: "start",
                });
              }}
            >
              {it.label}
            </a>
          );
        })}
      </div>
    </nav>
  );
}
